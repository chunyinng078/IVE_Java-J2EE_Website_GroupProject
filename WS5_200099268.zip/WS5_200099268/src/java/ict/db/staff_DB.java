/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ict.db;

import ict.bean.GymBean;
import ict.bean.TrainerBean;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author user
 */
public class staff_DB {

    private String url = "";
    private String username = "";
    private String password = "";

    public staff_DB(String url, String username, String password) {
        this.url = url;
        this.username = username;
        this.password = password;
    }

    public Connection getConnection() throws SQLException, IOException {
        try {
            //  System.setProperty("jdbc.drivers", "com.mysql.jdbc.Driver");
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(CustomerDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        return DriverManager.getConnection(url, username, password);
    }

    public ArrayList queryTrainer() {
        Connection cnnct = null;
        PreparedStatement pStmnt = null;
        try {
            cnnct = getConnection();
            String preQueryStatement = "SELECT * FROM  trainer";
            pStmnt = cnnct.prepareStatement(preQueryStatement);
            //Statement s = cnnct.createStatement();
            ResultSet rs = pStmnt.executeQuery();

            ArrayList list = new ArrayList();

            while (rs.next()) {
                TrainerBean tb = new TrainerBean();
                tb.setId(rs.getInt(1));
                tb.setName(rs.getString(2));
                tb.setStates(rs.getString(3));
                tb.setHrRate(rs.getString(4));
                tb.setDescription(rs.getString(5));
                tb.setImageID(rs.getInt(6));
                list.add(tb);
            }
            return list;
        } catch (SQLException ex) {
            while (ex != null) {
                ex.printStackTrace();
                ex = ex.getNextException();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            if (pStmnt != null) {
                try {
                    pStmnt.close();
                } catch (SQLException e) {
                }
            }
            if (cnnct != null) {
                try {
                    cnnct.close();
                } catch (SQLException sqlEx) {
                }
            }
        }
        return null;
    }

    public ArrayList<TrainerBean> queryTrainerByName(String name) {
        PreparedStatement pStmnt = null;
        Connection cnnct = null;
        TrainerBean tb = null;
        ArrayList<TrainerBean> ListTb = new ArrayList();
        try {
            cnnct = getConnection();
            String preQueryStatement = "SELECT * FROM trainer WHERE UPPER(name) LIKE UPPER(?)";
            pStmnt = cnnct.prepareStatement(preQueryStatement);
            pStmnt.setString(1, "%" + name + "%");
            ResultSet rs = null;
            rs = pStmnt.executeQuery();

            while (rs.next()) {
                tb = new TrainerBean(rs.getInt("id"), rs.getString("name"), rs.getString("states"), rs.getString("hrRate"), rs.getString("description"), rs.getInt("imageID"));
                ListTb.add(tb);
            }
            pStmnt.close();
            cnnct.close();
        } catch (SQLException ex) {
            while (ex != null) {
                ex.printStackTrace();
                ex = ex.getNextException();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return ListTb;
    }

    public ArrayList queryGym() {
        Connection cnnct = null;
        PreparedStatement pStmnt = null;
        try {
            cnnct = getConnection();
            String preQueryStatement = "SELECT * FROM  gymcenter";
            pStmnt = cnnct.prepareStatement(preQueryStatement);
            //Statement s = cnnct.createStatement();
            ResultSet rs = pStmnt.executeQuery();

            ArrayList list = new ArrayList();

            while (rs.next()) {
                GymBean gb = new GymBean();
                gb.setCenterName(rs.getString(1));
                gb.setDescription(rs.getString(2));
                gb.setStates(rs.getString(3));
                gb.setHrRate(rs.getString(4));
                gb.setImageID(rs.getInt(5));
                list.add(gb);
            }
            return list;
        } catch (SQLException ex) {
            while (ex != null) {
                ex.printStackTrace();
                ex = ex.getNextException();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            if (pStmnt != null) {
                try {
                    pStmnt.close();
                } catch (SQLException e) {
                }
            }
            if (cnnct != null) {
                try {
                    cnnct.close();
                } catch (SQLException sqlEx) {
                }
            }
        }
        return null;
    }

    public ArrayList<GymBean> queryGymByName(String name) {
        PreparedStatement pStmnt = null;
        Connection cnnct = null;
        GymBean Gb = null;
        ArrayList<GymBean> ListGb = new ArrayList();
        try {
            cnnct = getConnection();
            String preQueryStatement = "SELECT * FROM gymcenter WHERE UPPER(name) LIKE UPPER(?)";
            pStmnt = cnnct.prepareStatement(preQueryStatement);
            pStmnt.setString(1, "%" + name + "%");
            ResultSet rs = null;
            rs = pStmnt.executeQuery();

            while (rs.next()) {
                Gb = new GymBean(rs.getString("centerName"), rs.getString("states"), rs.getString("hrRate"), rs.getString("description"), rs.getInt("imageID"));
                ListGb.add(Gb);
            }
            pStmnt.close();
            cnnct.close();
        } catch (SQLException ex) {
            while (ex != null) {
                ex.printStackTrace();
                ex = ex.getNextException();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return ListGb;
    }

    public boolean delRecord(String value, String type) {
        Connection cnnct = null;
        PreparedStatement pStmnt = null;
        int num = 0;
        try {
            cnnct = getConnection();
            if ("trainer".equals(type)) {
                String preQueryStatement = "DELETE FROM trainer WHERE id=?";
                pStmnt = cnnct.prepareStatement(preQueryStatement);
                pStmnt.setString(1, value);

                num = pStmnt.executeUpdate();
            }else{
                String preQueryStatement = "DELETE FROM gymcenter WHERE centerName=?";
                pStmnt = cnnct.prepareStatement(preQueryStatement);
                pStmnt.setString(1, value);
                num = pStmnt.executeUpdate();
            }

        } catch (SQLException ex) {
            while (ex != null) {
                ex.printStackTrace();
                ex = ex.getNextException();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            if (pStmnt != null) {
                try {
                    pStmnt.close();
                } catch (SQLException e) {
                }
            }
            if (cnnct != null) {
                try {
                    cnnct.close();
                } catch (SQLException sqlEx) {
                }
            }
        }

        return (num == 1) ? true : false;
    }
}
