/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ict.servlet;

import ict.bean.GymBean;
import ict.bean.TrainerBean;
import ict.db.staff_DB;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author user
 */
@WebServlet(name = "HandleRecord", urlPatterns = {"/handleRecord"})
public class HandleRecord extends HttpServlet {

    private staff_DB db;

    @Override
    public void init() {
        //1.  obtain the context-param, dbUser, dbPassword and dbUrl which defined in web.xml
        String dbUser = this.getServletContext().getInitParameter("dbUser");
        String dbPassword = this.getServletContext().getInitParameter("dbPassword");
        String dbUrl = this.getServletContext().getInitParameter("dbUrl");

        //2.  create a new db object  with the parameter
        db = new staff_DB(dbUrl, dbUser, dbPassword);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String action = request.getParameter("action");

        if ("search".equalsIgnoreCase(action)) {
            // call the query db to get retrieve for all customer 
            String name = request.getParameter("name");
            String InformationType = request.getParameter("InformationType");
            if ("trainer".equals(InformationType)) {
                if (!"".equals(name)) {
                    ArrayList<TrainerBean> trainers = db.queryTrainerByName(name);
                    // set the result into the attribute	 
                    request.setAttribute("trainers", trainers);
                } else {
                    ArrayList<TrainerBean> trainers = db.queryTrainer();
                    // set the result into the attribute	 
                    request.setAttribute("trainers", trainers);
                }
                // redirect the result to the listCustomers.jsp
                RequestDispatcher rd;
                rd = getServletContext().getRequestDispatcher("/staff_listTrainers.jsp?action=listTrainers");
                rd.forward(request, response);
            } else if ("gym".equals(InformationType)) {
                if (!"".equals(name)) {
                    ArrayList<GymBean> gym = db.queryGymByName(name);
                    // set the result into the attribute	 
                    request.setAttribute("gym", gym);
                } else {
                    ArrayList<GymBean> gym = db.queryGym();
                    // set the result into the attribute	 
                    request.setAttribute("gym", gym);
                }
                // redirect the result to the listCustomers.jsp
                RequestDispatcher rd;
                rd = getServletContext().getRequestDispatcher("/staff_listTrainers.jsp?action=listGym");
                rd.forward(request, response);
            }

        } else if ("delete".equalsIgnoreCase(action)) {
            // call the query db to get retrieve for all customer 
            String type = request.getParameter("type");

            if ("trainer".equals(type)) {
                String id = request.getParameter("id");
                if (id != null) {
                    // call delete record method in the database
                    db.delRecord(id, type);
                    // redirect the result to list action 
                    response.sendRedirect("handleCustomer?action=listTrainers");
                }
            } else if ("gym".equals(type)) {
                String Name = request.getParameter("Name");
                if (Name != null) {
                    // call delete record method in the database
                    db.delRecord(Name, type);
                    // redirect the result to list action 
                    response.sendRedirect("handleCustomer?action=listGym");
                }

            } else {
                response.sendRedirect("staff_listTrainers.jsp?action=search");
            }
        }
    }
}
